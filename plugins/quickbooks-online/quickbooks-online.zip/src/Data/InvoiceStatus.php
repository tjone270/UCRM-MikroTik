<?php

declare(strict_types=1);

namespace QBExport\Data;

class InvoiceStatus
{
    public const DRAFT = 0;

    public const VOID = 4;
}
